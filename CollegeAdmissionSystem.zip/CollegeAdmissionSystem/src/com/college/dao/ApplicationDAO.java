package com.college.dao;

import com.college.model.Application;
import com.college.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ApplicationDAO {

    // ---------------------- Add New Application ----------------------
    public boolean apply(Application app) {
        String query = "INSERT INTO applications(student_id, course_id, marks, status) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, app.getStudentId());
            ps.setInt(2, app.getCourseId());
            ps.setDouble(3, app.getMarks());
            ps.setString(4, app.getStatus());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error applying: " + e.getMessage());
        }
        return false;
    }


    // ---------------------- Get all applications ----------------------
    public List<Application> getAllApplications() {
        List<Application> list = new ArrayList<>();
        String query = "SELECT * FROM applications";

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(query)) {

            while (rs.next()) {
                Application app = new Application(
                        rs.getInt("application_id"),
                        rs.getInt("student_id"),
                        rs.getInt("course_id"),
                        rs.getDouble("marks"),
                        rs.getString("status")
                );
                list.add(app);
            }

        } catch (Exception e) {
            System.out.println("Error fetching applications: " + e.getMessage());
        }
        return list;
    }


    // ---------------------- Approve/Reject Based on Merit & Cutoff ----------------------
    public boolean processApplication(int applicationId, double cutOff, int availableSeats) {

        String getQuery = "SELECT marks FROM applications WHERE application_id = ?";
        String updateQuery = "UPDATE applications SET status = ? WHERE application_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement getPs = conn.prepareStatement(getQuery);
             PreparedStatement updatePs = conn.prepareStatement(updateQuery)) {

            getPs.setInt(1, applicationId);
            ResultSet rs = getPs.executeQuery();

            if (rs.next()) {
                double marks = rs.getDouble("marks");

                String newStatus;
                if (availableSeats <= 0) {
                    newStatus = "REJECTED (NO SEATS)";
                } else if (marks >= cutOff) {
                    newStatus = "APPROVED";
                } else {
                    newStatus = "REJECTED (LOW MARKS)";
                }

                updatePs.setString(1, newStatus);
                updatePs.setInt(2, applicationId);
                return updatePs.executeUpdate() > 0;
            }

        } catch (Exception e) {
            System.out.println("Error processing application: " + e.getMessage());
        }

        return false;
    }


    // ---------------------- Get Applications by Course ----------------------
    public List<Application> getApplicationsByCourse(int courseId) {
        List<Application> list = new ArrayList<>();
        String query = "SELECT * FROM applications WHERE course_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Application(
                        rs.getInt("application_id"),
                        rs.getInt("student_id"),
                        rs.getInt("course_id"),
                        rs.getDouble("marks"),
                        rs.getString("status")
                ));
            }

        } catch (Exception e) {
            System.out.println("Error fetching course applications: " + e.getMessage());
        }
        return list;
    }
}
