package com.college.dao;

import com.college.model.Course;
import com.college.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {

    // Insert new course
    public boolean addCourse(Course course) {
        String query = "INSERT INTO courses(course_id, course_name, seats, cut_off) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, course.getCourseId());
            ps.setString(2, course.getCourseName());
            ps.setInt(3, course.getSeats());
            ps.setDouble(4, course.getCutOff());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error adding course: " + e.getMessage());
        }
        return false;
    }

    // Get all courses list
    public List<Course> getAllCourses() {
        List<Course> list = new ArrayList<>();
        String query = "SELECT * FROM courses";

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(query)) {

            while (rs.next()) {
                Course c = new Course(
                        rs.getInt("course_id"),
                        rs.getString("course_name"),
                        rs.getInt("seats"),
                        rs.getDouble("cut_off")
                );
                list.add(c);
            }

        } catch (Exception e) {
            System.out.println("Error fetching courses: " + e.getMessage());
        }

        return list;
    }

    // Get specific course by ID
    public Course getCourseById(int id) {
        String query = "SELECT * FROM courses WHERE course_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Course(
                        rs.getInt("course_id"),
                        rs.getString("course_name"),
                        rs.getInt("seats"),
                        rs.getDouble("cut_off")
                );
            }

        } catch (Exception e) {
            System.out.println("Error fetching course: " + e.getMessage());
        }
        return null;
    }

    // Delete course (optional)
    public boolean deleteCourse(int id) {
        String query = "DELETE FROM courses WHERE course_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error deleting course: " + e.getMessage());
        }
        return false;
    }
}
