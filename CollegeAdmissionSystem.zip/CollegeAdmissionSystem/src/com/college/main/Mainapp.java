package com.college.main;

import com.college.dao.*;
import com.college.model.*;

import java.util.List;
import java.util.Scanner;

public class Mainapp {

    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in)) {
			StudentDAO studentDAO = new StudentDAO();
			CourseDAO courseDAO = new CourseDAO();
			ApplicationDAO applicationDAO = new ApplicationDAO();

			while (true) {

			    System.out.println("\n===== COLLEGE ADMISSION SYSTEM =====");
			    System.out.println("1. Add Student");
			    System.out.println("2. Add Course");
			    System.out.println("3. Apply for Course");
			    System.out.println("4. View All Students");
			    System.out.println("5. View All Courses");
			    System.out.println("6. View All Applications");
			    System.out.println("7. Process Admission for a Course");
			    System.out.println("8. Exit");
			    System.out.print("Enter choice: ");
			    int ch = sc.nextInt();

			    switch (ch) {

			        // ------------------- 1. Add Student -------------------
			        case 1:
			            System.out.print("Enter Student ID: ");
			            int sid = sc.nextInt();
			            sc.nextLine();

			            System.out.print("Enter Name: ");
			            String name = sc.nextLine();

			            System.out.print("Enter Email: ");
			            String email = sc.nextLine();

			            System.out.print("Enter Marks: ");
			            double marks = sc.nextDouble();

			            Student st = new Student(sid, name, email, marks);

			            if (studentDAO.addStudent(st))
			                System.out.println("Student Added Successfully!");
			            else
			                System.out.println("Failed to add student.");

			            break;


			        // ------------------- 2. Add Course -------------------
			        case 2:
			            System.out.print("Enter Course ID: ");
			            int cid = sc.nextInt();
			            sc.nextLine();

			            System.out.print("Enter Course Name: ");
			            String cname = sc.nextLine();

			            System.out.print("Enter Seats: ");
			            int seats = sc.nextInt();

			            System.out.print("Enter Cut-Off Marks: ");
			            double cut = sc.nextDouble();

			            Course c = new Course(cid, cname, seats, cut);

			            if (courseDAO.addCourse(c))
			                System.out.println("Course Added Successfully!");
			            else
			                System.out.println("Failed to add course.");

			            break;


			        // ------------------- 3. Apply for Course -------------------
			        case 3:
			            System.out.print("Enter Student ID: ");
			            int sId = sc.nextInt();

			            System.out.print("Enter Course ID: ");
			            int cId = sc.nextInt();

			            System.out.print("Enter Marks: ");
			            double m = sc.nextDouble();

			            Application app = new Application(0, sId, cId, m, "PENDING");

			            if (applicationDAO.apply(app))
			                System.out.println("Application Submitted!");
			            else
			                System.out.println("Application Failed!");

			            break;


			        // ------------------- 4. View All Students -------------------
			        case 4:
			            List<Student> students = studentDAO.getAllStudents();
			            System.out.println("\n--- Student List ---");
			            for (Student s : students)
			                System.out.println(s);
			            break;


			        // ------------------- 5. View All Courses -------------------
			        case 5:
			            List<Course> courses = courseDAO.getAllCourses();
			            System.out.println("\n--- Course List ---");
			            for (Course cc : courses)
			                System.out.println(cc);
			            break;


			        // ------------------- 6. View All Applications -------------------
			        case 6:
			            List<Application> apps = applicationDAO.getAllApplications();
			            System.out.println("\n--- Application List ---");
			            for (Application a : apps)
			                System.out.println(a);
			            break;


			        // ------------------- 7. Process Admission -------------------
			        case 7:
			            System.out.print("Enter Course ID: ");
			            int courseId = sc.nextInt();

			            Course courseObj = courseDAO.getCourseById(courseId);

			            if (courseObj == null) {
			                System.out.println("Invalid Course ID!");
			                break;
			            }

			            List<Application> appList = applicationDAO.getApplicationsByCourse(courseId);

			            int availableSeats = courseObj.getSeats();
			            double cutoff = courseObj.getCutOff();

			            System.out.println("Processing applications...");

			            for (Application a : appList) {
			                applicationDAO.processApplication(a.getApplicationId(), cutoff, availableSeats);

			                if (a.getMarks() >= cutoff && availableSeats > 0) {
			                    availableSeats--;
			                }
			            }

			            System.out.println("Admission Process Completed!");
			            break;


			        // ------------------- 8. Exit -------------------
			        case 8:
			            System.out.println("Thank you!");
			            System.exit(0);
			            break;

			        default:
			            System.out.println("Invalid choice!");
			    }
			}
		}
    }
}
