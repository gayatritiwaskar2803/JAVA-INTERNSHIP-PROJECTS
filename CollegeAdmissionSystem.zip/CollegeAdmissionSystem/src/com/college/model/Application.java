package com.college.model;

public class Application {
    private int applicationId;
    private int studentId;
    private int courseId;
    private double marks;
    private String status;

    public Application() {}

    public Application(int applicationId, int studentId, int courseId, double marks, String status) {
        this.applicationId = applicationId;
        this.studentId = studentId;
        this.courseId = courseId;
        this.marks = marks;
        this.status = status;
    }

    public int getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(int applicationId) {
        this.applicationId = applicationId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public double getMarks() {
        return marks;
    }

    public void setMarks(double marks) {
        this.marks = marks;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Application ID: " + applicationId +
                ", Student ID: " + studentId +
                ", Course ID: " + courseId +
                ", Marks: " + marks +
                ", Status: " + status;
    }
}
