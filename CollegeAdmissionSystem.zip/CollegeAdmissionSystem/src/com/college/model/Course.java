package com.college.model;

public class Course {
    private int courseId;
    private String courseName;
    private int seats;
    private double cutOff;

    public Course() {}

    public Course(int courseId, String courseName, int seats, double cutOff) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.seats = seats;
        this.cutOff = cutOff;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public double getCutOff() {
        return cutOff;
    }

    public void setCutOff(double cutOff) {
        this.cutOff = cutOff;
    }

    @Override
    public String toString() {
        return "Course ID: " + courseId +
                ", Name: " + courseName +
                ", Seats: " + seats +
                ", Cut-Off: " + cutOff;
    }
}
