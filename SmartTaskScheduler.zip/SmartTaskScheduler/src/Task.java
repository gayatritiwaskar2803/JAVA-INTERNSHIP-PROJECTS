import java.time.LocalDate;

public class Task implements Comparable<Task> {

    private int id;
    private String title;
    private String priority;
    private LocalDate deadline;

    public Task(int id, String title, String priority, LocalDate deadline) {
        this.id = id;
        this.title = title;
        this.priority = priority;
        this.deadline = deadline;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getPriority() {
        return priority;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    // PRIORITY VALUE
    public int getPriorityValue() {
        switch (priority.toUpperCase()) {
            case "HIGH": return 1;
            case "MEDIUM": return 2;
            case "LOW": return 3;
            default: return 4;
        }
    }

    // COLOR ICON
    public String getColorIcon() {
        switch (priority.toUpperCase()) {
            case "HIGH": return "🔴 HIGH";
            case "MEDIUM": return "🟡 MEDIUM";
            case "LOW": return "🟢 LOW";
        }
        return priority;
    }

    @Override
    public int compareTo(Task o) {
        int byPriority = Integer.compare(this.getPriorityValue(), o.getPriorityValue());
        if (byPriority == 0) {
            return this.deadline.compareTo(o.deadline); // same priority → earlier deadline first
        }
        return byPriority;
    }

    @Override
    public String toString() {
        return "ID: " + id +
                "\nTitle: " + title +
                "\nPriority: " + getColorIcon() +
                "\nDeadline: " + deadline;
    }
}
