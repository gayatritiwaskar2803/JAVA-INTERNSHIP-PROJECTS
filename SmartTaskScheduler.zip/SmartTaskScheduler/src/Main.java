public class Main {
    public static void main(String[] args) {

        TaskManager tm = new TaskManager();

        // Automatic Daily Reminder
        tm.showTodayTasks();

        while (true) {
            System.out.println("\n==== TASK MANAGER ====");
            System.out.println("1. Add Task");
            System.out.println("2. View Tasks (Priority)");
            System.out.println("3. View Tasks (Deadline)");
            System.out.println("4. Search Task");
            System.out.println("5. Remove Task");
            System.out.println("6. Export to CSV");
            System.out.println("7. Exit");
            System.out.print("Choose: ");

            int ch = tm.sc.nextInt();

            switch (ch) {
                case 1: tm.addTask(); break;
                case 2: tm.viewTasks(); break;
                case 3: tm.viewByDeadline(); break;
                case 4: tm.searchTask(); break;
                case 5: tm.removeTask(); break;
                case 6: tm.exportToCSV(); break;
                case 7: System.exit(0);
                default:
                    System.out.println("Invalid input!");
            }
        }
    }
}
