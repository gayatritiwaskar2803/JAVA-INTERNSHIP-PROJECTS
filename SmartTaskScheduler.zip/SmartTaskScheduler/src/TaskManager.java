import java.io.FileWriter;
import java.time.LocalDate;
import java.util.PriorityQueue;
import java.util.Scanner;

public class TaskManager {

    PriorityQueue<Task> taskQueue = new PriorityQueue<>();
    Scanner sc = new Scanner(System.in);

    // --- DAILY REMINDER ---
    public void showTodayTasks() {
        LocalDate today = LocalDate.now();
        System.out.println("\n📅 Today’s Tasks (" + today + "):");

        boolean found = false;
        for (Task t : taskQueue) {
            if (t.getDeadline().equals(today)) {
                System.out.println(t + "\n----------------");
                found = true;
            }
        }
        if (!found)
            System.out.println("No tasks due today!");
    }

    // --- ADD TASK ---
    public void addTask() {
        System.out.print("Enter Task ID: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Task Title: ");
        String title = sc.nextLine();

        System.out.print("Enter Priority (HIGH/MEDIUM/LOW): ");
        String priority = sc.nextLine().toUpperCase();

        System.out.print("Enter Deadline (yyyy-mm-dd): ");
        LocalDate deadline = LocalDate.parse(sc.nextLine());

        Task t = new Task(id, title, priority, deadline);
        taskQueue.add(t);

        System.out.println("\nTask Added ✔\n");
    }

    // --- VIEW BY PRIORITY (DEFAULT) ---
    public void viewTasks() {
        if (taskQueue.isEmpty()) {
            System.out.println("No tasks added!");
            return;
        }
        System.out.println("\n--- TASK LIST (Sorted by Priority + Deadline) ---");
        for (Task t : taskQueue) {
            System.out.println(t + "\n------------------");
        }
    }

    // --- SORT ONLY BY DEADLINE ---
    public void viewByDeadline() {
        if (taskQueue.isEmpty()) {
            System.out.println("No tasks added!");
            return;
        }

        System.out.println("\n--- TASKS SORTED BY DEADLINE ---");

        taskQueue.stream()
                .sorted((a, b) -> a.getDeadline().compareTo(b.getDeadline()))
                .forEach(t -> {
                    System.out.println(t + "\n----------------");
                });
    }

    // --- REMOVE TASK ---
    public void removeTask() {
        System.out.print("Enter ID to remove: ");
        int id = sc.nextInt();

        Task remove = null;
        for (Task t : taskQueue) {
            if (t.getId() == id) {
                remove = t;
                break;
            }
        }

        if (remove != null) {
            taskQueue.remove(remove);
            System.out.println("Task Removed!");
        } else {
            System.out.println("Task Not Found!");
        }
    }

    // --- SEARCH BY ID / TITLE ---
    public void searchTask() {
        sc.nextLine();
        System.out.print("Search Keyword (ID or Title): ");
        String key = sc.nextLine().toLowerCase();

        System.out.println("\n--- Search Results ---");
        boolean found = false;

        for (Task t : taskQueue) {
            if (String.valueOf(t.getId()).contains(key) ||
                t.getTitle().toLowerCase().contains(key)) {
                System.out.println(t + "\n----------------");
                found = true;
            }
        }
        if (!found) System.out.println("No matching task found!");
    }

    // --- EXPORT TO CSV ---
    public void exportToCSV() {
        try {
            FileWriter fw = new FileWriter("tasks.csv");
            fw.write("ID,Title,Priority,Deadline\n");

            for (Task t : taskQueue) {
                fw.write(t.getId() + "," + t.getTitle() + "," +
                        t.getPriority() + "," + t.getDeadline() + "\n");
            }
            fw.close();
            System.out.println("CSV Exported → tasks.csv");
        } catch (Exception e) {
            System.out.println("Error exporting CSV: " + e.getMessage());
        }
    }
}
